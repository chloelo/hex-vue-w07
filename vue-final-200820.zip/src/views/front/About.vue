<template>
  <div class="about">
    <h2>關於我們</h2>
  </div>
</template>
