<template>
  <div>
    <h2>我是首頁</h2>
  </div>
</template>
<script>
export default {
  data() {
    return {
      isLoading: false,
    };
  },
};
</script>
